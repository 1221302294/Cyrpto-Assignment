from Crypto.Cipher import AES
import base64

# Unpadding function
def unpad(data):
    return data[:-data[-1]]

# Load decrypted AES key
decrypted_aes_key = bytes.fromhex(input("Enter decrypted AES key (hex): "))

# Load encrypted data
encrypted_data = base64.b64decode(open("ciphertext.txt").read())

# Extract IV from received ciphertext
received_iv = encrypted_data[:16]
received_ciphertext = encrypted_data[16:]

# Create AES cipher for decryption
cipher_aes = AES.new(decrypted_aes_key, AES.MODE_CBC, received_iv)

# Decrypt and unpad message
decrypted_message = unpad(cipher_aes.decrypt(received_ciphertext))

print("Decrypted Message:", decrypted_message.decode())
