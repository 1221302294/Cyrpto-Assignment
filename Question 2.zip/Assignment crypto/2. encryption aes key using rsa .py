from Crypto.Cipher import PKCS1_OAEP
from Crypto.PublicKey import RSA
from Crypto.Random import get_random_bytes
import base64

# Load public key of Person B
pub_key = RSA.import_key(open("public.pem").read())

# Generate a 128-bit AES key
aes_key = get_random_bytes(16)

# Encrypt AES key using RSA
cipher_rsa = PKCS1_OAEP.new(pub_key)
encrypted_aes_key = cipher_rsa.encrypt(aes_key)

# Save encrypted AES key
to_save = base64.b64encode(encrypted_aes_key).decode()
with open("encrypted_aes_key.txt", "w") as file:
    file.write(to_save)

print("Encrypted AES Key Saved.")