from Crypto.Cipher import AES
from Crypto.Random import get_random_bytes
import base64

# Padding function
def pad(data):
    pad_len = 16 - (len(data) % 16)
    return data + bytes([pad_len] * pad_len)

# Load decrypted AES key
decrypted_aes_key = bytes.fromhex(input("Enter decrypted AES key (hex): "))

# Message to encrypt
message = b"Confidential Data"

# Generate an IV (Initialization Vector)
iv = get_random_bytes(16)

# Create AES cipher in CBC mode
cipher_aes = AES.new(decrypted_aes_key, AES.MODE_CBC, iv)

# Encrypt and pad message
ciphertext = cipher_aes.encrypt(pad(message))

# Save encrypted data
encrypted_data = base64.b64encode(iv + ciphertext).decode()
with open("ciphertext.txt", "w") as file:
    file.write(encrypted_data)

print("Ciphertext Saved.")