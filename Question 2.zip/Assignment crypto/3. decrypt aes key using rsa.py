from Crypto.Cipher import PKCS1_OAEP
from Crypto.PublicKey import RSA
import base64

# Load private key of Person B
priv_key = RSA.import_key(open("private.pem").read())

# Load encrypted AES key
encrypted_aes_key = base64.b64decode(open("encrypted_aes_key.txt").read())

# Decrypt AES key
cipher_rsa = PKCS1_OAEP.new(priv_key)
decrypted_aes_key = cipher_rsa.decrypt(encrypted_aes_key)

print("Decrypted AES Key:", decrypted_aes_key.hex())