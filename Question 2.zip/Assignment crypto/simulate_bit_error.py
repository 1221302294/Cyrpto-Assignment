from Crypto.Cipher import AES
import base64

# Unpadding function
def unpad(data):
    return data[:-data[-1]]

# Load decrypted AES key
decrypted_aes_key = bytes.fromhex(input("Enter decrypted AES key (hex): "))

# Load encrypted data
encrypted_data = base64.b64decode(open("ciphertext.txt").read())

# Extract IV from received ciphertext
received_iv = encrypted_data[:16]
received_ciphertext = bytearray(encrypted_data[16:])

# Introduce a bit error
received_ciphertext[10] ^= 0xFF  # Flip a random bit

# Create AES cipher for decryption
cipher_aes = AES.new(decrypted_aes_key, AES.MODE_CBC, received_iv)

try:
    corrupted_decrypted_message = unpad(cipher_aes.decrypt(bytes(received_ciphertext)))
    print("Decrypted Message with Bit Error:", corrupted_decrypted_message)
except Exception as e:
    print("Decryption failed due to bit error:", str(e))
